import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3N0ZXBoZW4tYnVpbGRzLnVrL3N1cHJlbWFjeS9ob21lLnR4dA==')
PornBase = 'http://stephen-builds.uk/home%20(1).txt'
addon = xbmcaddon.Addon('plugin.video.supremacy')
name = 'plugin.video.supremacy'