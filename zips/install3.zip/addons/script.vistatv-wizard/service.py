import xbmc
import utils
import os
import xbmcgui
import sfile
import urllib
import urllib2
import time
import re
import downloader
import extractor
import xbmcvfs
import shutil


HOME        = xbmc.translatePath('special://home/')
done      =  os.path.join(HOME, 'done.xml')
import os.path
if os.path.exists(done):
    exit()
xbmc.executebuiltin("XBMC.AlarmClock('MTVBCS',XBMC.RunAddon(script.vistatv-wizard),1,silent)")