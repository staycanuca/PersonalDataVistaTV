import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3EwZTkxaDF1')
addon = xbmcaddon.Addon('plugin.video.SkyNet')