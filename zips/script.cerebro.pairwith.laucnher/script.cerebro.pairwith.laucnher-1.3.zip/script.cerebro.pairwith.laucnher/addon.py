import time
import xbmc
import os
import xbmcgui
import urllib2
     
xbmc.executebuiltin('RunAddon(script.cerebro.pairwith)')