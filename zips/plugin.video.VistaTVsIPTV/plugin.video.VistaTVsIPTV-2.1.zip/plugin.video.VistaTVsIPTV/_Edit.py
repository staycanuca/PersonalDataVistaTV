import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/biglad/PersonalDataVistaTV/master/zips/to-be-cleaned-up-ed/super%20old%20stuff/9534958459845345/sdfdsfdsfdsfsdfsfdsf/1/2/lol/wtf/iptv-links.xml'
addon = xbmcaddon.Addon('plugin.video.VistaTVsIPTV')